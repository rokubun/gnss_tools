cp rtkget_qt ../../../RTKLIB_bin/bin
